# AI Agent Workflow Builder

A mini n8n for chaining AI agent steps, built on nhost + Hasura + Postgres + Next.js.

## Repo layout

```
db/functions/          Postgres migrations + seed
hasura/metadata/        Tracked tables, relationships, permissions, Actions, cron, event triggers
functions/               Express service implementing the Action handlers, cron dispatcher,
                         event-trigger receiver, and public webhook endpoint
web/                     Next.js frontend
```

## Prerequisites

- Docker + the [Nhost CLI](https://docs.nhost.io/reference/cli) (`nhost up` runs Postgres + Hasura + Auth locally),
  or an nhost cloud project
- Node.js 18+
- (Optional) a free-tier LLM API key — Groq, OpenRouter, or Gemini all have one. Without a key the
  `llm_call` step uses a **disclosed stub** (see `functions/lib/llm.js`) that returns a clearly
  marked fake response with a realistic artificial delay, so the pipeline's timing/UX still works.

## 1. Start nhost locally

```bash
nhost up
```

This provisions Postgres, Hasura, and Auth on your machine. Note the local Hasura console URL and
GraphQL endpoint it prints.

## 2. Apply the schema

```bash
psql "$DATABASE_URL" -f db/migrations/001_init_schema.sql
```

(Or use `nhost` CLI's own migration tooling if you prefer — the SQL is plain and framework-agnostic.)

## 3. Apply Hasura metadata

Copy the contents of `hasura/metadata/` into your project's Hasura metadata directory (or apply via
the Hasura console's "metadata" import), then:

```bash
hasura metadata apply
hasura metadata reload
```

Before applying, replace `{{ACTIONS_BASE_URL}}` in `actions.yaml`, `cron_triggers.yaml`, and the
`orders` event trigger in `tables.yaml` with wherever you'll run the `functions/` service (e.g.
`http://host.docker.internal:4000` for local Docker, or your deployed URL). Also set the
`ACTIONS_SECRET` env var in your Hasura project to match `functions/.env`.

## 4. Run the Action handler service

```bash
cd functions
cp .env.example .env   # fill in DATABASE_URL, ACTIONS_SECRET, ACTIONS_BASE_URL, and an LLM key if you have one
npm install
npm start
```

This is the piece that actually executes `triggerWorkflowRun`, `approveStep`, the scheduled-run
dispatcher, the `orders` database-event receiver, and the public `/webhook/:token` endpoint.

## 5. Run the frontend

```bash
cd web
cp .env.local.example .env.local   # fill in your nhost subdomain/region and Hasura URLs
npm install
npm run dev
```

Open http://localhost:3000, sign up (nhost Auth), and you're in.

## Demo scenario setup

The Final Task needs two orgs with real users in different roles:

1. Sign up two users through the app's login screen (or `nhost` Auth directly) for **Org A**
   (e.g. `alice@orga.test` as owner, `bob@orga.test` as editor) and one for **Org B**
   (`carol@orgb.test` as owner).
2. Run `db/seed.sql` to create the two `organizations` rows.
3. Look up each user's id (`select id, email from auth.users;`) and insert the matching
   `org_members` rows (the seed file has a commented template for this).
4. Log in as Alice, build a workflow in Org A with an `llm_call`, an `http_request`, a
   `conditional_branch`, and an `approval_gate`, plus a manual trigger and a webhook (or scheduled)
   trigger.
5. Run it once from the UI (manual), and once by `curl -X POST <base>/webhook/<token>` (webhook) or
   waiting for the cron dispatcher (scheduled).
6. Approve the paused `approval_gate` step as Bob (editor) or Alice (owner) from the run view.
7. Log out, log in as Carol (Org B), and confirm she cannot see Org A's workflow, cannot trigger
   it, and a direct GraphQL query for its `id` (or its `workflow_run_id` / `step_run_id`) returns
   nothing — Hasura's relationship-based permissions re-check org membership on every row, not just
   at the list level.

## Design notes

See `WRITEUP.md` for schema reasoning, how the two permission layers are enforced, and how
approval-gate pause/resume works. Key points, briefly:

- **Single Hasura role.** Because a user's role (owner/editor/viewer) is per-org data in
  `org_members`, not a fixed session role, every table permission uses one `user` Hasura role and a
  relationship filter through `org_members` — this is what keeps a same-role user in a different org
  from ever seeing another org's rows, including by guessing IDs directly.
- **Two permission layers, two different enforcement mechanisms.** Layer 1 (org+role scoping) is
  pure Hasura declarative permissions. Layer 2 (step-level gating for `db_write`/`notify`/webhook
  triggers) is also declarative, but expressed as a boolean expression on the row's own `type`
  column. Approval-gate clearing is **not** a declarative permission at all — it's a mid-execution
  decision, so `workflow_runs`/`step_runs` have no direct mutation permissions for the `user` role;
  the only way to advance a run is through the `triggerWorkflowRun`/`approveStep` Actions, which
  re-derive the caller's org role from `org_members` inside the handler before doing anything.
- **In-request execution for the demo.** `runWorkflow()` executes steps synchronously inside the
  Action handler for simplicity/demo speed. A production build would enqueue the run and let the
  `step_runs` subscription reflect progress purely asynchronously so `triggerWorkflowRun` returns
  instantly regardless of workflow length — noted as a known simplification.
- **Retries.** `llm_call` and `http_request` retry up to 3 attempts with linear backoff
  (`functions/lib/engine.js`); the final failure is recorded on both the `step_runs` row and the
  parent `workflow_run`.
- **Quota.** Checked at run-creation time (across all trigger types, not just manual) and
  incremented once per successfully completed run; the period rolls over automatically once
  `quota_reset_at` has passed.
