# Write-up

## Schema reasoning

The relationship chain the spec asks for — org → members → workflows → steps/triggers, workflow →
runs → step_runs — is modeled directly as foreign keys, nothing denormalized except two columns:
`workflow_runs.org_id` and `step_runs.org_id`. Those are redundant with `workflow_id`'s own org, but
without them every permission check and every Action-handler authorization query would need an extra
join through `workflows` just to find out which org a run belongs to — and both of those code paths
run on every single request. Denormalizing the org id once at write time (it's `workflow.org_id`,
copied in when the run/step_run is created, so it can never drift) keeps every downstream permission
filter and quota lookup a single-hop relationship instead of a two-hop one.

`workflow_steps.config` and `workflow_triggers.config` are `jsonb` rather than a rigid column per
step type because the six step types have almost nothing in common shape-wise (`llm_call` needs a
prompt and model; `conditional_branch` needs a field/operator/value and two branch targets;
`approval_gate` needs a required role) — a shared schema would be either six mostly-null tables or
one table with a dozen nullable columns. `jsonb` keeps the table narrow and lets new step types be
added without a migration; the trade-off is that the *engine* (`functions/lib/engine.js`), not the
database, is responsible for validating each type's config shape.

`step_type`, `trigger_type`, `run_status`, and `step_run_status` are Postgres enums rather than free
text so an invalid type/status can't be inserted at all, and so Layer 2's permission expressions
(which branch on `type`) don't have to defend against typos.

## The two permission layers

**Layer 1 (org + role scoping)** is enforced entirely by Hasura declarative permissions on a single
`user` role. Every select/insert/update/delete filter walks the relevant relationship
(`workflow → org → members`, or `step → workflow → org → members`) and checks
`members.user_id = X-Hasura-User-Id` (existence = you can see it) and, for writes,
`members.role = _in [...]` (sufficiency = you can change it). Because this is a relationship
re-evaluated per row on every request, an editor in Org A gets zero rows back for an Org B
workflow_id they guess directly — there's no separate "can this org be listed" check to bypass,
since listing and single-row fetch use the identical filter.

**Layer 2 (step-level gating)** reuses the same mechanism but adds a second condition on the row's
own `type` column: inserting/updating a `db_write` or `notify` step, or a `webhook` trigger, requires
`role = owner` specifically, while every other type only requires `owner` or `editor`. This is
expressed as `_or: [{type: not in [...]}, {type: in [...], role: owner}]` — still a pure Hasura
permission, just a stricter one gated on content instead of just relationship existence.

**Clearing an approval_gate is deliberately *not* a Hasura permission at all.** It's a decision that
depends on the step's own `config.required_role`, which isn't knowable until the step is reached at
runtime, and it also has a side effect (resuming execution) that a row update can't trigger safely.
So `workflow_runs`/`step_runs` have no `user`-role mutation permissions whatsoever — the only way to
advance a run is through the `approveStep` Action. Inside that handler
(`functions/server.js`), the caller's role is re-derived fresh from `org_members` (never trusted from
the client), compared against the paused step's `config.required_role`, and only then is the row
updated and `runWorkflow()` re-invoked to continue past the gate. This also means the pause/resume
state machine lives in one place: a run is "paused" exactly when its `current_step_id` points at an
`approval_gate` step_run with `status = 'paused'`, and "resume" is just re-entering
`runWorkflow()` at that same index after flipping the step_run to `succeeded`.
