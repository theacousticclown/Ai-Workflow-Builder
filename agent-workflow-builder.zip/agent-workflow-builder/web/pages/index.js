import Link from 'next/link';
import { useAuthenticated, useUserId } from '@nhost/react';
import { useQuery } from '@apollo/client';
import { useRouter } from 'next/router';
import { MY_ORGS } from '../lib/queries';

export default function Home() {
  const isAuthenticated = useAuthenticated();
  const userId = useUserId();
  const router = useRouter();
  const { data, loading, error } = useQuery(MY_ORGS, { skip: !isAuthenticated });

  if (!isAuthenticated) {
    if (typeof window !== 'undefined') router.replace('/login');
    return null;
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">Workflow Builder</div>
      </aside>
      <main className="main">
        <h1>Your organizations</h1>
        {loading && <p>Loading…</p>}
        {error && <p style={{ color: 'var(--accent-fail)' }}>{error.message}</p>}
        {data?.organizations.map((org) => {
          const myRole = org.members.find((m) => m.user_id === userId)?.role;
          return (
            <Link key={org.id} href={`/orgs/${org.id}/workflows`} style={{ textDecoration: 'none' }}>
              <div className="card" style={{ cursor: 'pointer' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <h3 style={{ margin: 0 }}>{org.name}</h3>
                  <span className="badge">{myRole}</span>
                </div>
                <div className="quota-bar-track">
                  <div
                    className="quota-bar-fill"
                    style={{ width: `${Math.min(100, (org.quota_used / org.quota_allowed) * 100)}%` }}
                  />
                </div>
                <small style={{ color: 'var(--text-dim)' }}>
                  {org.quota_used} / {org.quota_allowed} calls used this period
                </small>
              </div>
            </Link>
          );
        })}
      </main>
    </div>
  );
}
