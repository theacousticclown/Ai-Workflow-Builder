import { useState } from 'react';
import { useRouter } from 'next/router';
import { useSignInEmailPassword, useAuthenticated } from '@nhost/react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { signInEmailPassword, isLoading, error } = useSignInEmailPassword();
  const isAuthenticated = useAuthenticated();
  const router = useRouter();

  if (isAuthenticated) {
    router.replace('/');
    return null;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const result = await signInEmailPassword(email, password);
    if (result.isSuccess) router.push('/');
  }

  return (
    <div style={{ display: 'grid', placeItems: 'center', minHeight: '100vh' }}>
      <form onSubmit={handleSubmit} className="card" style={{ width: 320 }}>
        <h2 style={{ marginTop: 0 }}>Sign in</h2>
        <div style={{ marginBottom: 12 }}>
          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{ width: '100%', padding: 8, marginTop: 4 }}
            required
          />
        </div>
        <div style={{ marginBottom: 16 }}>
          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{ width: '100%', padding: 8, marginTop: 4 }}
            required
          />
        </div>
        {error && <p style={{ color: 'var(--accent-fail)' }}>{error.message}</p>}
        <button type="submit" disabled={isLoading} style={{ width: '100%' }}>
          {isLoading ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
    </div>
  );
}
