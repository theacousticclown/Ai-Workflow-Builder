import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useQuery, useMutation } from '@apollo/client';
import { useUserId } from '@nhost/react';
import { MY_ORGS, ORG_WORKFLOWS, ADD_STEP, ADD_TRIGGER } from '../../../../../lib/queries';

const ALL_STEP_TYPES = [
  { value: 'llm_call', label: 'LLM call', ownerOnly: false },
  { value: 'http_request', label: 'HTTP request', ownerOnly: false },
  { value: 'conditional_branch', label: 'Conditional branch', ownerOnly: false },
  { value: 'approval_gate', label: 'Approval gate', ownerOnly: false },
  { value: 'db_write', label: 'DB write', ownerOnly: true },
  { value: 'notify', label: 'Notify (Slack/email)', ownerOnly: true },
];

const TRIGGER_TYPES = [
  { value: 'manual', label: 'Manual', ownerOnly: false },
  { value: 'scheduled', label: 'Scheduled (cron)', ownerOnly: false },
  { value: 'database_event', label: 'Database event', ownerOnly: false },
  { value: 'webhook', label: 'Webhook', ownerOnly: true },
];

export default function EditWorkflow() {
  const router = useRouter();
  const { orgId, workflowId } = router.query;
  const userId = useUserId();

  const { data: orgsData } = useQuery(MY_ORGS, { skip: !orgId });
  const { data, loading, refetch } = useQuery(ORG_WORKFLOWS, { variables: { org_id: orgId }, skip: !orgId });
  const [addStep] = useMutation(ADD_STEP);
  const [addTrigger] = useMutation(ADD_TRIGGER);

  const myRole = orgsData?.organizations
    .find((o) => o.id === orgId)
    ?.members.find((m) => m.user_id === userId)?.role;
  const isOwner = myRole === 'owner';

  const workflow = data?.workflows.find((w) => w.id === workflowId);

  const [stepType, setStepType] = useState('llm_call');
  const [stepName, setStepName] = useState('');
  const [stepConfig, setStepConfig] = useState('{}');
  const [triggerType, setTriggerType] = useState('manual');
  const [triggerConfig, setTriggerConfig] = useState('{}');
  const [lastWebhookToken, setLastWebhookToken] = useState(null);

  async function handleAddStep(e) {
    e.preventDefault();
    let config;
    try {
      config = JSON.parse(stepConfig || '{}');
    } catch {
      alert('Step config must be valid JSON');
      return;
    }
    const nextOrder = (workflow?.steps.length || 0) + 1;
    try {
      await addStep({
        variables: { workflow_id: workflowId, step_order: nextOrder, type: stepType, name: stepName || stepType, config },
      });
      setStepName('');
      setStepConfig('{}');
      await refetch();
    } catch (err) {
      alert(err.message);
    }
  }

  async function handleAddTrigger(e) {
    e.preventDefault();
    let config;
    try {
      config = JSON.parse(triggerConfig || '{}');
    } catch {
      alert('Trigger config must be valid JSON');
      return;
    }
    try {
      const { data: res } = await addTrigger({ variables: { workflow_id: workflowId, type: triggerType, config } });
      if (triggerType === 'webhook') setLastWebhookToken(res.insert_workflow_triggers_one.webhook_token);
      await refetch();
    } catch (err) {
      alert(err.message);
    }
  }

  if (loading || !workflow) return <div className="main">Loading…</div>;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">Workflow Builder</div>
        <Link href={`/orgs/${orgId}/workflows`}>← Workflows</Link>
      </aside>
      <main className="main">
        <h1>{workflow.name}</h1>

        <div className="card">
          <h3>Steps</h3>
          {workflow.steps.map((s) => (
            <div key={s.id} className="step-row">
              <span className="badge">{s.step_order}</span>
              <strong>{s.type}</strong>
              <span>{s.name}</span>
            </div>
          ))}
          {workflow.steps.length === 0 && <p style={{ color: 'var(--text-dim)' }}>No steps yet.</p>}

          <form onSubmit={handleAddStep} style={{ marginTop: 16, display: 'grid', gap: 8 }}>
            <select value={stepType} onChange={(e) => setStepType(e.target.value)}>
              {ALL_STEP_TYPES.filter((t) => !t.ownerOnly || isOwner).map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                  {t.ownerOnly ? ' (owner only)' : ''}
                </option>
              ))}
            </select>
            <input placeholder="Step name" value={stepName} onChange={(e) => setStepName(e.target.value)} />
            <textarea
              placeholder='Config JSON, e.g. {"prompt": "Summarize: {{previous.text}}"}'
              value={stepConfig}
              onChange={(e) => setStepConfig(e.target.value)}
              rows={3}
              style={{ fontFamily: 'var(--font-mono)', fontSize: 12 }}
            />
            <button type="submit">Add step</button>
          </form>
        </div>

        <div className="card">
          <h3>Triggers</h3>
          {workflow.triggers.map((t) => (
            <div key={t.id} className="step-row">
              <strong>{t.type}</strong>
              <span className="badge">{t.is_enabled ? 'enabled' : 'disabled'}</span>
              {t.type === 'webhook' && t.webhook_token && (
                <code style={{ fontSize: 11 }}>/webhook/{t.webhook_token}</code>
              )}
            </div>
          ))}

          <form onSubmit={handleAddTrigger} style={{ marginTop: 16, display: 'grid', gap: 8 }}>
            <select value={triggerType} onChange={(e) => setTriggerType(e.target.value)}>
              {TRIGGER_TYPES.filter((t) => !t.ownerOnly || isOwner).map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                  {t.ownerOnly ? ' (owner only)' : ''}
                </option>
              ))}
            </select>
            {triggerType === 'scheduled' && (
              <input
                placeholder='cron, e.g. "*/15 * * * *"'
                onChange={(e) => setTriggerConfig(JSON.stringify({ cron: e.target.value }))}
              />
            )}
            {triggerType === 'database_event' && (
              <input
                placeholder='watched table, e.g. "orders"'
                onChange={(e) => setTriggerConfig(JSON.stringify({ watched_table: e.target.value }))}
              />
            )}
            <button type="submit">Add trigger</button>
          </form>
          {lastWebhookToken && (
            <p style={{ color: 'var(--accent-live)', fontFamily: 'var(--font-mono)', fontSize: 12 }}>
              Webhook created. POST to: /webhook/{lastWebhookToken}
            </p>
          )}
        </div>
      </main>
    </div>
  );
}
