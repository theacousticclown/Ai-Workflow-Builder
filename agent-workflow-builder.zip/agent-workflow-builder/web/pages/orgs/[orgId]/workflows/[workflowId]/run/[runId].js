import Link from 'next/link';
import { useRouter } from 'next/router';
import { useSubscription, useMutation } from '@apollo/client';
import { STEP_RUN_SUBSCRIPTION, APPROVE_STEP } from '../../../../../../lib/queries';

const TONE_BY_STATUS = {
  running: 'live',
  succeeded: 'live',
  paused: 'wait',
  failed: 'fail',
};

export default function RunView() {
  const router = useRouter();
  const { orgId, workflowId, runId } = router.query;
  const { data, loading } = useSubscription(STEP_RUN_SUBSCRIPTION, {
    variables: { workflow_run_id: runId },
    skip: !runId,
  });
  const [approveStep, { loading: approving }] = useMutation(APPROVE_STEP);

  async function handleApprove(stepRunId) {
    try {
      await approveStep({ variables: { step_run_id: stepRunId } });
    } catch (err) {
      alert(err.message);
    }
  }

  const run = data?.workflow_runs_by_pk;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">Workflow Builder</div>
        <Link href={`/orgs/${orgId}/workflows/${workflowId}/edit`}>← Workflow</Link>
      </aside>
      <main className="main">
        <h1>
          Run status: {run && <span className="badge" data-tone={TONE_BY_STATUS[run.status]}>{run.status}</span>}
        </h1>
        {run?.error && <p style={{ color: 'var(--accent-fail)' }}>{run.error}</p>}

        {loading && <p>Connecting…</p>}

        <div className="card">
          {data?.step_runs.map((sr) => (
            <div key={sr.id} className="step-row" data-status={sr.status}>
              <span className="badge">{sr.step.step_order}</span>
              <strong>{sr.step.type}</strong>
              <span style={{ flex: 1 }}>{sr.step.name}</span>
              <span className="badge" data-tone={TONE_BY_STATUS[sr.status]}>
                {sr.status}
              </span>
              {sr.attempt_count > 1 && <small style={{ color: 'var(--text-dim)' }}>attempt {sr.attempt_count}</small>}

              {sr.status === 'paused' && sr.step.type === 'approval_gate' && (
                <button className="approve" disabled={approving} onClick={() => handleApprove(sr.id)}>
                  {approving ? 'Approving…' : 'Approve'}
                </button>
              )}
            </div>
          ))}
          {data?.step_runs.length === 0 && <p style={{ color: 'var(--text-dim)' }}>Waiting for the first step…</p>}
        </div>
      </main>
    </div>
  );
}
