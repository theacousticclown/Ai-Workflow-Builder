import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useQuery, useMutation } from '@apollo/client';
import { useUserId } from '@nhost/react';
import { MY_ORGS, ORG_WORKFLOWS, ORG_USAGE, CREATE_WORKFLOW, TRIGGER_WORKFLOW_RUN } from '../../../../lib/queries';

export default function OrgWorkflows() {
  const router = useRouter();
  const { orgId } = router.query;
  const userId = useUserId();
  const [newName, setNewName] = useState('');

  const { data: orgsData } = useQuery(MY_ORGS, { skip: !orgId });
  const { data, loading, refetch } = useQuery(ORG_WORKFLOWS, { variables: { org_id: orgId }, skip: !orgId });
  const { data: usageData } = useQuery(ORG_USAGE, { variables: { org_id: orgId }, skip: !orgId, pollInterval: 15000 });
  const [createWorkflow] = useMutation(CREATE_WORKFLOW);
  const [triggerRun] = useMutation(TRIGGER_WORKFLOW_RUN);

  const myOrg = orgsData?.organizations.find((o) => o.id === orgId);
  const myRole = myOrg?.members.find((m) => m.user_id === userId)?.role;
  const canEdit = myRole === 'owner' || myRole === 'editor';
  const usage = usageData?.org_usage_this_month?.[0];

  async function handleCreate(e) {
    e.preventDefault();
    if (!newName.trim()) return;
    const { data: created } = await createWorkflow({ variables: { org_id: orgId, name: newName, description: '' } });
    setNewName('');
    await refetch();
    router.push(`/orgs/${orgId}/workflows/${created.insert_workflows_one.id}/edit`);
  }

  async function handleRun(workflowId) {
    try {
      const { data: runData } = await triggerRun({ variables: { workflow_id: workflowId } });
      router.push(`/orgs/${orgId}/workflows/${workflowId}/run/${runData.triggerWorkflowRun.workflow_run_id}`);
    } catch (err) {
      alert(err.message);
    }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">Workflow Builder</div>
        <Link href="/">← Organizations</Link>
      </aside>
      <main className="main">
        <h1>{myOrg?.name || 'Workflows'}</h1>
        {usage && (
          <div className="card">
            <strong>Usage this period</strong>
            <div className="quota-bar-track">
              <div
                className="quota-bar-fill"
                style={{ width: `${Math.min(100, (usage.quota_used / usage.quota_allowed) * 100)}%` }}
              />
            </div>
            <small style={{ color: 'var(--text-dim)' }}>
              {usage.quota_used} / {usage.quota_allowed} calls · {usage.runs_this_month} runs this month
              {usage.avg_run_duration_seconds
                ? ` · avg ${Math.round(usage.avg_run_duration_seconds)}s per run`
                : ''}
            </small>
          </div>
        )}

        {canEdit && (
          <form onSubmit={handleCreate} className="card" style={{ display: 'flex', gap: 8 }}>
            <input
              placeholder="New workflow name"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              style={{ flex: 1, padding: 8 }}
            />
            <button type="submit">Create workflow</button>
          </form>
        )}

        {loading && <p>Loading…</p>}
        {data?.workflows.map((wf) => {
          const lastRun = wf.runs[0];
          return (
            <div key={wf.id} className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h3 style={{ margin: 0 }}>
                    <Link href={`/orgs/${orgId}/workflows/${wf.id}/edit`}>{wf.name}</Link>
                  </h3>
                  <small style={{ color: 'var(--text-dim)' }}>
                    {wf.steps.length} steps · {wf.triggers.map((t) => t.type).join(', ') || 'no trigger yet'}
                  </small>
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  {lastRun && (
                    <Link href={`/orgs/${orgId}/workflows/${wf.id}/run/${lastRun.id}`}>
                      <span className="badge" data-tone={lastRun.status === 'paused' ? 'wait' : lastRun.status === 'failed' ? 'fail' : lastRun.status === 'succeeded' ? 'live' : undefined}>
                        {lastRun.status}
                      </span>
                    </Link>
                  )}
                  {/* Run button hidden for viewers */}
                  {canEdit && (
                    <button onClick={() => handleRun(wf.id)}>Run</button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </main>
    </div>
  );
}
