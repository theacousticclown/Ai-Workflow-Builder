import { ApolloProvider } from '@apollo/client';
import { NhostProvider } from '@nhost/react';
import { nhost } from '../lib/nhost';
import { apolloClient } from '../lib/apollo';
import '../styles/globals.css';

export default function App({ Component, pageProps }) {
  return (
    <NhostProvider nhost={nhost}>
      <ApolloProvider client={apolloClient}>
        <Component {...pageProps} />
      </ApolloProvider>
    </NhostProvider>
  );
}
