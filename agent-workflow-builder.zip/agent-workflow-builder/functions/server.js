require('dotenv').config();
const express = require('express');
const parser = require('cron-parser');
const { pool, withTransaction } = require('./lib/db');
const { getCallerUserId, requireActionsSecret, getRoleInOrg, roleAtLeast } = require('./lib/auth');
const { hasQuotaRemaining } = require('./lib/quota');
const { runWorkflow } = require('./lib/engine');

const app = express();
app.use(express.json());

// ---------------------------------------------------------------------
// POST /triggerWorkflowRun  (Hasura Action: triggerWorkflowRun)
// ---------------------------------------------------------------------
app.post('/triggerWorkflowRun', async (req, res) => {
  try {
    const userId = getCallerUserId(req);
    const { workflow_id } = req.body.input;

    const result = await withTransaction(async (client) => {
      const { rows: wfRows } = await client.query(
        `select id, org_id, is_active from workflows where id = $1`,
        [workflow_id]
      );
      if (!wfRows.length) {
        const e = new Error('Workflow not found');
        e.statusCode = 404;
        throw e;
      }
      const workflow = wfRows[0];

      // ---- Layer 1: org + role scoping ----
      const role = await getRoleInOrg(client, userId, workflow.org_id);
      if (!roleAtLeast(role, 'editor')) {
        const e = new Error('Only an owner or editor in this workflow\'s org can trigger a run');
        e.statusCode = 403;
        throw e;
      }

      if (!workflow.is_active) {
        const e = new Error('Workflow is inactive');
        e.statusCode = 400;
        throw e;
      }

      // ---- Quota check ----
      const ok = await hasQuotaRemaining(client, workflow.org_id);
      if (!ok) {
        const e = new Error('Organization quota exhausted for this period');
        e.statusCode = 429;
        throw e;
      }

      const { rows: runRows } = await client.query(
        `insert into workflow_runs (workflow_id, org_id, status, triggered_by_user, trigger_type)
         values ($1, $2, 'pending', $3, 'manual')
         returning *`,
        [workflow_id, workflow.org_id, userId]
      );
      return runRows[0];
    });

    // Execute steps. Kept in-request for the assignment's demo
    // simplicity; a production build would enqueue this and let the
    // subscription reflect progress entirely async (see README).
    await withTransaction((client) => runWorkflow(client, result.id));

    const { rows: finalRows } = await pool.query(`select status from workflow_runs where id = $1`, [result.id]);

    res.json({ workflow_run_id: result.id, status: finalRows[0].status });
  } catch (err) {
    console.error(err);
    res.status(err.statusCode || 500).json({ message: err.message || 'Internal error' });
  }
});

// ---------------------------------------------------------------------
// POST /approveStep  (Hasura Action: approveStep)
// ---------------------------------------------------------------------
app.post('/approveStep', async (req, res) => {
  try {
    const userId = getCallerUserId(req);
    const { step_run_id } = req.body.input;

    await withTransaction(async (client) => {
      const { rows } = await client.query(
        `select sr.id, sr.org_id, sr.workflow_run_id, sr.status, ws.config
           from step_runs sr
           join workflow_steps ws on ws.id = sr.step_id
          where sr.id = $1
          for update`,
        [step_run_id]
      );
      if (!rows.length) {
        const e = new Error('step_run not found');
        e.statusCode = 404;
        throw e;
      }
      const stepRun = rows[0];

      if (stepRun.status !== 'paused') {
        const e = new Error('This step is not awaiting approval');
        e.statusCode = 400;
        throw e;
      }

      // ---- Layer 2: step-level gating, re-checked here explicitly ----
      // (this is exactly the "mid-execution decision" the spec calls out
      // as something a plain Hasura row permission can't express, since
      // it depends on required_role from the step's own config.)
      const requiredRole = (stepRun.config && stepRun.config.required_role) || 'owner';
      const role = await getRoleInOrg(client, userId, stepRun.org_id);
      if (!roleAtLeast(role, requiredRole)) {
        const e = new Error(`Only a(n) ${requiredRole} in this org can approve this step`);
        e.statusCode = 403;
        throw e;
      }

      await client.query(
        `update step_runs
            set status = 'succeeded', approved_by = $2, approved_at = now(), finished_at = now(),
                output = jsonb_build_object('approved', true)
          where id = $1`,
        [step_run_id, userId]
      );
    });

    // Resume execution from the step right after the gate.
    await withTransaction(async (client) => {
      const { rows } = await client.query(`select workflow_run_id from step_runs where id = $1`, [step_run_id]);
      const workflowRunId = rows[0].workflow_run_id;
      const { rows: runRows } = await client.query(`select workflow_id, current_step_id from workflow_runs where id = $1`, [workflowRunId]);
      const { workflow_id, current_step_id } = runRows[0];
      const { rows: stepRows } = await client.query(
        `select id from workflow_steps where workflow_id = $1 order by step_order asc`,
        [workflow_id]
      );
      const idx = stepRows.findIndex((s) => s.id === current_step_id);
      const nextStep = stepRows[idx + 1];
      await client.query(`update workflow_runs set current_step_id = $2, status = 'running' where id = $1`, [
        workflowRunId,
        nextStep ? nextStep.id : null,
      ]);
      await runWorkflow(client, workflowRunId);
    });

    const { rows: finalRows } = await pool.query(`select status from step_runs where id = $1`, [step_run_id]);
    res.json({ step_run_id, status: finalRows[0].status });
  } catch (err) {
    console.error(err);
    res.status(err.statusCode || 500).json({ message: err.message || 'Internal error' });
  }
});

// ---------------------------------------------------------------------
// POST /webhook/:token  — inbound endpoint for the Webhook trigger type.
// Public (no Hasura session), authorized purely by the unguessable
// per-trigger token minted when the trigger row was created.
// ---------------------------------------------------------------------
app.post('/webhook/:token', async (req, res) => {
  try {
    const { token } = req.params;

    const runId = await withTransaction(async (client) => {
      const { rows } = await client.query(
        `select wt.workflow_id, w.org_id, w.is_active
           from workflow_triggers wt
           join workflows w on w.id = wt.workflow_id
          where wt.webhook_token = $1 and wt.type = 'webhook' and wt.is_enabled = true`,
        [token]
      );
      if (!rows.length) {
        const e = new Error('Unknown or disabled webhook');
        e.statusCode = 404;
        throw e;
      }
      const { workflow_id, org_id, is_active } = rows[0];
      if (!is_active) {
        const e = new Error('Workflow is inactive');
        e.statusCode = 400;
        throw e;
      }

      const ok = await hasQuotaRemaining(client, org_id);
      if (!ok) {
        const e = new Error('Organization quota exhausted');
        e.statusCode = 429;
        throw e;
      }

      const { rows: runRows } = await client.query(
        `insert into workflow_runs (workflow_id, org_id, status, triggered_by_user, trigger_type)
         values ($1, $2, 'pending', null, 'webhook')
         returning id`,
        [workflow_id, org_id]
      );
      return runRows[0].id;
    });

    await withTransaction((client) => runWorkflow(client, runId));
    res.json({ workflow_run_id: runId });
  } catch (err) {
    console.error(err);
    res.status(err.statusCode || 500).json({ message: err.message || 'Internal error' });
  }
});

// ---------------------------------------------------------------------
// POST /internal/dispatchScheduledRuns  — hit every minute by the
// Hasura cron trigger. Finds scheduled triggers due right now.
// ---------------------------------------------------------------------
app.post('/internal/dispatchScheduledRuns', async (req, res) => {
  try {
    requireActionsSecret(req);

    const { rows: triggers } = await pool.query(
      `select wt.id, wt.workflow_id, wt.config, w.org_id, w.is_active
         from workflow_triggers wt
         join workflows w on w.id = wt.workflow_id
        where wt.type = 'scheduled' and wt.is_enabled = true and w.is_active = true`
    );

    const started = [];
    for (const trig of triggers) {
      const cron = trig.config && trig.config.cron;
      if (!cron) continue;
      if (!isDueThisMinute(cron)) continue;

      const runId = await withTransaction(async (client) => {
        const ok = await hasQuotaRemaining(client, trig.org_id);
        if (!ok) return null;
        const { rows } = await client.query(
          `insert into workflow_runs (workflow_id, org_id, status, triggered_by_user, trigger_type)
           values ($1, $2, 'pending', null, 'scheduled') returning id`,
          [trig.workflow_id, trig.org_id]
        );
        return rows[0].id;
      });

      if (runId) {
        await withTransaction((client) => runWorkflow(client, runId));
        started.push(runId);
      }
    }

    res.json({ started });
  } catch (err) {
    console.error(err);
    res.status(err.statusCode || 500).json({ message: err.message || 'Internal error' });
  }
});

function isDueThisMinute(cronExpr) {
  try {
    const interval = parser.parseExpression(cronExpr, { currentDate: new Date(Date.now() - 60000) });
    const next = interval.next();
    const diffMs = Math.abs(next.getTime() - Date.now());
    return diffMs < 60000;
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------
// POST /internal/onOrdersInsert  — Hasura Event Trigger receiver for
// the `orders` table (the assignment's "Database event" trigger type).
// ---------------------------------------------------------------------
app.post('/internal/onOrdersInsert', async (req, res) => {
  try {
    requireActionsSecret(req);

    const newRow = req.body.event && req.body.event.data && req.body.event.data.new;
    if (!newRow) return res.json({ started: [] });

    const { rows: triggers } = await pool.query(
      `select wt.id, wt.workflow_id, w.org_id, w.is_active
         from workflow_triggers wt
         join workflows w on w.id = wt.workflow_id
        where wt.type = 'database_event'
          and wt.is_enabled = true
          and w.is_active = true
          and w.org_id = $1
          and wt.config->>'watched_table' = 'orders'`,
      [newRow.org_id]
    );

    const started = [];
    for (const trig of triggers) {
      const runId = await withTransaction(async (client) => {
        const ok = await hasQuotaRemaining(client, trig.org_id);
        if (!ok) return null;
        const { rows } = await client.query(
          `insert into workflow_runs (workflow_id, org_id, status, triggered_by_user, trigger_type)
           values ($1, $2, 'pending', null, 'database_event') returning id`,
          [trig.workflow_id, trig.org_id]
        );
        return rows[0].id;
      });
      if (runId) {
        await withTransaction((client) => runWorkflow(client, runId));
        started.push(runId);
      }
    }

    res.json({ started });
  } catch (err) {
    console.error(err);
    res.status(err.statusCode || 500).json({ message: err.message || 'Internal error' });
  }
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`Action handler listening on :${port}`));
