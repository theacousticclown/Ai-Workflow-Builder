-- Run this AFTER at least two users have signed up through nhost auth
-- (see README "Demo scenario setup"). auth.users rows must already
-- exist — we can't fabricate valid authenticated users here.
--
-- Usage:
--   1. Sign up alice@orga.test and bob@orga.test (Org A: owner + editor)
--   2. Sign up carol@orgb.test (Org B: owner)
--   3. Find their user ids: select id, email from auth.users;
--   4. Fill in the ids below and run this file.

insert into organizations (id, name, quota_allowed, quota_used)
values
  ('11111111-1111-1111-1111-111111111111', 'Org A', 100, 0),
  ('22222222-2222-2222-2222-222222222222', 'Org B', 100, 0)
on conflict (id) do nothing;

-- Replace the user_id UUIDs below with real auth.users.id values.
-- insert into org_members (org_id, user_id, role) values
--   ('11111111-1111-1111-1111-111111111111', '<alice-user-id>', 'owner'),
--   ('11111111-1111-1111-1111-111111111111', '<bob-user-id>',   'editor'),
--   ('22222222-2222-2222-2222-222222222222', '<carol-user-id>', 'owner');
