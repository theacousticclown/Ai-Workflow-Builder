-- =====================================================================
-- AI Agent Workflow Builder — core schema
-- Postgres 14+ / nhost
-- =====================================================================

create extension if not exists "pgcrypto"; -- gen_random_uuid()

-- ---------------------------------------------------------------------
-- organizations
-- ---------------------------------------------------------------------
create table organizations (
  id                uuid primary key default gen_random_uuid(),
  name              text not null,
  quota_period      text not null default 'monthly',      -- 'monthly' | 'daily' (kept simple)
  quota_allowed     integer not null default 1000,          -- calls allowed per period
  quota_used        integer not null default 0,             -- calls used in current period
  quota_reset_at    timestamptz not null default date_trunc('month', now()) + interval '1 month',
  created_at        timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- org_members — join table user <-> org with a role
-- auth.users is the nhost/Hasura-managed users table
-- ---------------------------------------------------------------------
create table org_members (
  id                uuid primary key default gen_random_uuid(),
  org_id            uuid not null references organizations(id) on delete cascade,
  user_id           uuid not null references auth.users(id) on delete cascade,
  role              text not null check (role in ('owner', 'editor', 'viewer')),
  created_at        timestamptz not null default now(),
  unique (org_id, user_id)
);

create index idx_org_members_user on org_members(user_id);
create index idx_org_members_org on org_members(org_id);

-- ---------------------------------------------------------------------
-- workflows
-- ---------------------------------------------------------------------
create table workflows (
  id                uuid primary key default gen_random_uuid(),
  org_id            uuid not null references organizations(id) on delete cascade,
  name              text not null,
  description       text,
  is_active         boolean not null default true,
  created_by        uuid not null references auth.users(id),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index idx_workflows_org on workflows(org_id);

-- ---------------------------------------------------------------------
-- workflow_steps — ordered steps belonging to a workflow
-- ---------------------------------------------------------------------
create type step_type as enum (
  'llm_call',
  'http_request',
  'db_write',
  'notify',
  'conditional_branch',
  'approval_gate'
);

create table workflow_steps (
  id                uuid primary key default gen_random_uuid(),
  workflow_id       uuid not null references workflows(id) on delete cascade,
  step_order        integer not null,
  type              step_type not null,
  name              text not null,
  config            jsonb not null default '{}'::jsonb,
  -- config shape depends on type, e.g.:
  --   llm_call:            { "prompt": "...", "model": "..." }
  --   http_request:         { "url": "...", "method": "POST", "body": {...} }
  --   db_write:             { "table": "...", "mapping": {...} }
  --   notify:               { "channel": "slack"|"email", "target": "...", "template": "..." }
  --   conditional_branch:   { "condition": "output.contains('x')", "on_true_step": id, "on_false_step": id }
  --   approval_gate:        { "required_role": "owner" }
  created_at        timestamptz not null default now(),
  unique (workflow_id, step_order)
);

create index idx_workflow_steps_workflow on workflow_steps(workflow_id);

-- ---------------------------------------------------------------------
-- workflow_triggers
-- ---------------------------------------------------------------------
create type trigger_type as enum ('manual', 'webhook', 'scheduled', 'database_event');

create table workflow_triggers (
  id                uuid primary key default gen_random_uuid(),
  workflow_id       uuid not null references workflows(id) on delete cascade,
  type              trigger_type not null,
  config            jsonb not null default '{}'::jsonb,
  -- webhook:         { "secret": "..." }                      (webhook_token below is the real check)
  -- scheduled:       { "cron": "*/15 * * * *" }
  -- database_event:  { "watched_table": "orders", "op": "INSERT" }
  webhook_token     uuid default gen_random_uuid(),           -- unguessable inbound token for webhook triggers
  is_enabled        boolean not null default true,
  created_at        timestamptz not null default now()
);

create index idx_workflow_triggers_workflow on workflow_triggers(workflow_id);
create unique index idx_workflow_triggers_webhook_token on workflow_triggers(webhook_token) where type = 'webhook';

-- ---------------------------------------------------------------------
-- workflow_runs — one per execution
-- ---------------------------------------------------------------------
create type run_status as enum ('pending', 'running', 'paused', 'succeeded', 'failed', 'cancelled');

create table workflow_runs (
  id                uuid primary key default gen_random_uuid(),
  workflow_id       uuid not null references workflows(id) on delete cascade,
  org_id            uuid not null references organizations(id) on delete cascade, -- denormalized for fast/scoped permission checks
  status            run_status not null default 'pending',
  triggered_by_user uuid references auth.users(id),           -- null for non-manual triggers
  trigger_type      trigger_type not null,
  current_step_id   uuid references workflow_steps(id),
  started_at        timestamptz not null default now(),
  finished_at       timestamptz,
  error             text
);

create index idx_workflow_runs_workflow on workflow_runs(workflow_id);
create index idx_workflow_runs_org on workflow_runs(org_id);

-- ---------------------------------------------------------------------
-- step_runs — one per step per run
-- ---------------------------------------------------------------------
create type step_run_status as enum ('pending', 'running', 'paused', 'succeeded', 'failed', 'skipped');

create table step_runs (
  id                uuid primary key default gen_random_uuid(),
  workflow_run_id   uuid not null references workflow_runs(id) on delete cascade,
  step_id           uuid not null references workflow_steps(id) on delete cascade,
  org_id            uuid not null references organizations(id) on delete cascade, -- denormalized for permission scoping
  status            step_run_status not null default 'pending',
  input             jsonb,
  output            jsonb,
  error             text,
  attempt_count     integer not null default 0,
  approved_by       uuid references auth.users(id),
  approved_at       timestamptz,
  started_at        timestamptz,
  finished_at       timestamptz,
  created_at        timestamptz not null default now()
);

create index idx_step_runs_run on step_runs(workflow_run_id);
create index idx_step_runs_org on step_runs(org_id);

-- =====================================================================
-- Aggregation: org-level usage this month (Postgres view)
-- Exposed to Hasura as a tracked view for the "usage indicator" query
-- =====================================================================
create view org_usage_this_month as
select
  o.id as org_id,
  o.name as org_name,
  o.quota_allowed,
  o.quota_used,
  o.quota_allowed - o.quota_used as quota_remaining,
  count(wr.id) filter (
    where wr.started_at >= date_trunc('month', now())
  ) as runs_this_month,
  avg(extract(epoch from (wr.finished_at - wr.started_at)))
    filter (where wr.finished_at is not null) as avg_run_duration_seconds
from organizations o
left join workflow_runs wr on wr.org_id = o.id
group by o.id, o.name, o.quota_allowed, o.quota_used;

-- ---------------------------------------------------------------------
-- updated_at trigger for workflows
-- ---------------------------------------------------------------------
create or replace function set_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger trg_workflows_updated_at
  before update on workflows
  for each row execute function set_updated_at();

-- =====================================================================
-- Example "business" table used to demonstrate the database_event
-- trigger type end-to-end. Org-scoped like everything else. In a real
-- deployment, whichever table an org wants to watch would live here or
-- in a similar org-scoped table of the user's own design.
-- =====================================================================
create table orders (
  id                uuid primary key default gen_random_uuid(),
  org_id            uuid not null references organizations(id) on delete cascade,
  customer_name     text not null,
  amount_cents      integer not null,
  status            text not null default 'new',
  created_at        timestamptz not null default now()
);

create index idx_orders_org on orders(org_id);
